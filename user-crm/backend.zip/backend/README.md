# Loop CRM Backend — Authentication Starter

Django REST Framework authentication foundation.

## Included
- Custom email-based user model
- Roles: super_admin, admin, analyst, support
- JWT login with database role validation
- Remember Me: refresh token 30 days; otherwise 1 day
- Super Admin-only staff registration
- Refresh, logout (blacklist), and current-user endpoints
- MySQL environment configuration and basic API throttling

## Setup (Windows PowerShell)
```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
Copy-Item .env.example .env
```
Create the MySQL database:
```sql
CREATE DATABASE loop_crm CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
```
Edit `.env`, then:
```powershell
python manage.py makemigrations authentication
python manage.py migrate
python manage.py createsuperuser
python manage.py runserver
```
The first superuser is assigned the super_admin role.

## Endpoints
- POST `/api/auth/login/`
- POST `/api/auth/register/` (Super Admin only)
- POST `/api/auth/refresh/`
- POST `/api/auth/logout/`
- GET `/api/auth/me/`

Login JSON:
```json
{"email":"admin@loop.com","password":"your-password","role":"super_admin","remember_me":true}
```
The role sent by the frontend is checked against the stored role; it does not grant permissions.

Registration JSON:
```json
{"email":"analyst@loop.com","password":"StrongPassword@123","first_name":"Loop","last_name":"Analyst","role":"analyst"}
```

Send `Authorization: Bearer <access-token>` for protected APIs.

## Production hardening still required
Add verified email/password reset, login lockout and stronger throttling, audit events, HTTPS, secrets management, monitoring, and secure HttpOnly refresh-cookie + CSRF handling for browser deployments. This starter returns JWTs in JSON for initial integration. Do not switch AUTH_USER_MODEL on an already-migrated default-user database without a migration plan.
